This is ClubMgr as shipped in CW 2.0 using Legacy Templates.

I compiled in C10. The orignal CW2 .6APP and OLD_DCT are in the folder.

I fixed a few issues:

	Some MDI Windows had the TOOLBOX that had to be removed.
	The About graphic had to be changed.

In 5.5 or 6 two Legacy Embeds changed order. 
	Now "After Opening the Window" is above "Before Resizing ...".
	This can result in some code to not work the same, or WinResize GPF.
	See my comments in BrowseMembers for more info.


  !CARL Note:
  ! This WinResze.Set call here will GPF because the WinResize.Init is 
  ! done below in the "Before Resizing Window From INI file" embed. (See IMO Below)
  ! This was from CW 2. In C6 two Embeds moved in Legacy to match ABC
  ! so now "After Opening the Window" is above "Before Resizing ..."
  ! This is more logical but can break code as seen here. I have a Utility
  ! template to find procedures with Code in BOTH Embeds.
  ! That would NOT find this situation caused by the WinResize, but I may be able to adapt
  !
  ! IMO this reveals FLAWs in the WindowResizeType Class (ResCode.clw).
  ! It does not NEW its ControlQueue and ResizeQueue queues until .Init().
  ! Those should be NEW in a CONSTRUCT and DISPOSE in DESTRUCT
  ! At minimum it should ASSERT(NOT Q &= NULL) in the methods. 
  ! Plus a check IF (Q &= NULL) THEN REUTRN.
  ! The WinResize class should NOT CRASH THE ENTIRE PROGRAM !
	